package com.zhanlang.hw.entity;

public class Version {
	private String version_id ;
	private String memory_version ;
	private int price ;
	@Override
	public String toString() {
		return "T_goods_version [version_id=" + version_id + ", memory_version=" + memory_version + ", price=" + price
				+ "]";
	}
	public String getVersion_id() {
		return version_id;
	}
	public void setVersion_id(String version_id) {
		this.version_id = version_id;
	}
	public String getMemory_version() {
		return memory_version;
	}
	public void setMemory_version(String memory_version) {
		this.memory_version = memory_version;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
}
