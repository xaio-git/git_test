package com.zhanlang.hw.entity;

public class Select {

	
		 private String model_name ;
		 private String series_id;
		 private int show_price;
		 private String show_img ;
		 @Override
		public String toString() {
			return "T_goods_select [model_name=" + model_name + ", series_id=" + series_id + ", show_price="
					+ show_price + ", show_img=" + show_img + ", comment_num=" + comment_num + ", stock=" + stock
					+ ", period_free=" + period_free + ", perferential=" + perferential + ", screen_size=" + screen_size
					+ ", running_memory=" + running_memory + ", MEMORY=" + MEMORY + "]";
		}
		public String getModel_name() {
			return model_name;
		}
		public Select(String model_name, String series_id, int show_price, String show_img, int comment_num,
				int stock, int period_free, int perferential, float screen_size, int running_memory, int mEMORY) {
			super();
			this.model_name = model_name;
			this.series_id = series_id;
			this.show_price = show_price;
			this.show_img = show_img;
			this.comment_num = comment_num;
			this.stock = stock;
			this.period_free = period_free;
			this.perferential = perferential;
			this.screen_size = screen_size;
			this.running_memory = running_memory;
			MEMORY = mEMORY;
		}
		public void setModel_name(String model_name) {
			this.model_name = model_name;
		}
		public String getSeries_id() {
			return series_id;
		}
		public void setSeries_id(String series_id) {
			this.series_id = series_id;
		}
		public int getShow_price() {
			return show_price;
		}
		public void setShow_price(int show_price) {
			this.show_price = show_price;
		}
		public String getShow_img() {
			return show_img;
		}
		public void setShow_img(String show_img) {
			this.show_img = show_img;
		}
		public int getComment_num() {
			return comment_num;
		}
		public void setComment_num(int comment_num) {
			this.comment_num = comment_num;
		}
		public int getStock() {
			return stock;
		}
		public void setStock(int stock) {
			this.stock = stock;
		}
		public int getPeriod_free() {
			return period_free;
		}
		public void setPeriod_free(int period_free) {
			this.period_free = period_free;
		}
		public int getPerferential() {
			return perferential;
		}
		public void setPerferential(int perferential) {
			this.perferential = perferential;
		}
		public float getScreen_size() {
			return screen_size;
		}
		public void setScreen_size(float screen_size) {
			this.screen_size = screen_size;
		}
		public int getRunning_memory() {
			return running_memory;
		}
		public void setRunning_memory(int running_memory) {
			this.running_memory = running_memory;
		}
		public int getMEMORY() {
			return MEMORY;
		}
		public void setMEMORY(int mEMORY) {
			MEMORY = mEMORY;
		}
		private int comment_num ;
		 private int stock ;
		 private int period_free ;
		 private int perferential;
		 private float screen_size ;
		 private int 	running_memory ;
		 private int 	MEMORY;
}
