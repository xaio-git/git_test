package com.zhanlang.hw.entity;

public class Buy {
	private String goods_id ;
	private String model_name ;
	private String phone_color;
	@Override
	public String toString() {
		return "T_buy_info [goods_id=" + goods_id + ", model_name=" + model_name + ", phone_color=" + phone_color
				+ ", now_time=" + now_time + "]";
	}
	public String getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(String goods_id) {
		this.goods_id = goods_id;
	}
	public String getModel_name() {
		return model_name;
	}
	public void setModel_name(String model_name) {
		this.model_name = model_name;
	}
	public String getPhone_color() {
		return phone_color;
	}
	public void setPhone_color(String phone_color) {
		this.phone_color = phone_color;
	}
	public String getNow_time() {
		return now_time;
	}
	public void setNow_time(String now_time) {
		this.now_time = now_time;
	}
	private String now_time ;
}
