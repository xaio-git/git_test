package com.zhanlang.hw.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zhanlang.hw.dao.GoodsDao;
import com.zhanlang.hw.entity.Version;
import com.zhanlang.hw.service.VersionService;


@Service
public class VersionServiceImpl implements VersionService{

	@Autowired
	private GoodsDao goodsDao;
	@Override
	public Version selectByVersion (String memory_version) {
		Version v=goodsDao.selectByVersion(memory_version);
		return v;
	}
}
