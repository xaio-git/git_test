package com.zhanlang.hw.service;

import org.springframework.stereotype.Repository;

import com.zhanlang.hw.entity.Version;

@Repository
public interface VersionService {
	public Version selectByVersion(String memory_version);
    }
	

