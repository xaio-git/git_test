package com.zhanlang.hw.service;

import com.zhanlang.hw.entity.Version;

public interface SelectService {

	public Version selectByVersion (String memory_version);
	
	
		
	}


