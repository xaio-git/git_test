package com.zhanlang.hw.dao;

import com.zhanlang.hw.entity.Select;

public interface SelectDao {

	/* @Select("select * from T_goods_select where model_name =#{modelName}") */
	public Select selectByname (String model_name);

}
