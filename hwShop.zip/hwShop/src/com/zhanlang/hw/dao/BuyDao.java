package com.zhanlang.hw.dao;

public interface BuyDao {
    
}
