package com.zhanlang.hw.dao;

import org.apache.ibatis.annotations.Select;

import com.zhanlang.hw.entity.Version;

public interface GoodsDao {
     @Select("select price from T_goods_version where memory_version=#{memory_version}")
	public Version selectByVersion (String memory_version);
}
