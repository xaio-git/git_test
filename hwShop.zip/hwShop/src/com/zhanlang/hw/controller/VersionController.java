package com.zhanlang.hw.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zhanlang.hw.entity.Version;
import com.zhanlang.hw.service.SelectService;
import com.zhanlang.hw.service.VersionService;

@Controller
public class VersionController {

	@Autowired
	private VersionService versionService;

	@Autowired
	private SelectService selectService;

	@RequestMapping( "/findAdminById")
	public String selectByVersion( String memory_version ,HttpSession session) {
		Version v= versionService.selectByVersion(memory_version);
		session.setAttribute("v",v);
		return "";
	}
}