package com.zhanlang.hw.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zhanlang.hw.entity.Select;
import com.zhanlang.hw.service.SelectService;

@Controller
public class SelectController {

	@Autowired
	private SelectService selectService;
	
	@RequestMapping("/index")
	public String index(String model_name,Model model) {
		
	Select select=	selectService.selectByname(model_name);
	model.addAttribute("msg",select);    
		
		return "";	
	}
}
